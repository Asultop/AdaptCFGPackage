chcp 65001
@echo off
type autoexec.cfg >> ../autoexec.cfg
echo 完成
echo 你可以安全地关闭此窗口 You Can Close This Window Safe And Sound！
pause